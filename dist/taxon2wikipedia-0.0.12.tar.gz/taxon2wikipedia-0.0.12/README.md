# taxon2wikipedia

An automatic page builder for ptwiki. 


Reflora JSON hidden API:

In English: https://floradobrasil2020.jbrj.gov.br/reflora/listaBrasil/ConsultaPublicaUC/ResultadoDaConsultaCarregaTaxonGrupo.do?&idDadosListaBrasil={fb_id}"

In Portuguese: "http://reflora.jbrj.gov.br/reflora/listaBrasil/ConsultaPublicaUC/ResultadoDaConsultaCarregaTaxonGrupo.do?&idDadosListaBrasil={fb_id}"

## Set up

Set up pywikibot as per [this tutorial](https://www.mediawiki.org/wiki/Manual:Pywikibot/Installation).

```
python3 ~/Apps/pywikibot/pwb.py ~/Apps/pywikibot/generate_user_files


```
